<?php 
 
class Throttle extends \Eloquent {
 
    protected $table = 'throttle';
 
    //protected $softDelete = true;

    
}