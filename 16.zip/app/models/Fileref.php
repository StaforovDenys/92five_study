<?php 
 
class Fileref extends \Eloquent {
 
    protected $table = 'file_ref';
 
     protected $softDelete = true;

   
 
}