<?php

class Quicknote extends Eloquent{

	protected $table = 'quicknote';
}